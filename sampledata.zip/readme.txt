Run the testdata using
java -jar DEMViewerExample.jar xyz map.xyz real texture.jpg -y 3